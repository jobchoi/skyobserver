package com.example.skyobserver;

public class Common {
    public static final String SERVER_URL="http://192.168.0.23:8081/hanulshop";
}
