package com.example.skyobserver.member;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.skyobserver.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Signup extends AppCompatActivity {

    String strEmail ;
    private byte state = 0x00;
    private boolean flag = false;

    EditText pwd ;
    EditText repwd ;

    String regExpn = "^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
            + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
            + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
            + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
            + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
            + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$";
    CharSequence inputStr;

//    public boolean isEmailValid(String email) {
//        return true;
//    }


    @Override
    protected void onPostResume() {
        super.onPostResume();
/*        EditText inputID = findViewById(R.id.id_my);

        inputID.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus){
                    Toast.makeText(Signup.this, "setOnFocusChangeListener 발생 - if", Toast.LENGTH_SHORT).show();
                    // new SendSignupDataTaask().execute();
                } else{
                    Toast.makeText(Signup.this, "setOnFocusChangeListener 발생 - else", Toast.LENGTH_SHORT).show();
                }
            }
        });*/
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("회원가입");


        Button signUpButton = findViewById(R.id.buttonEnroll);

        pwd = findViewById(R.id.pwd_my);
        repwd = findViewById(R.id.repwd_my);


        final EditText email = findViewById(R.id.email_my);



        strEmail = email.getText().toString();

        // --------------------- 유효성 검사 - Email ---------------------
        email.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus){
                    Log.d("hasFocus","!hasFocus");
                    // 이메일 유효성 검사
                    inputStr = email.getText().toString();

                    Pattern pattern = Pattern.compile(regExpn, Pattern.CASE_INSENSITIVE);
                    Matcher matcher = pattern.matcher(inputStr);
                    if (matcher.matches()) {
                        Toast.makeText(Signup.this, "ok", Toast.LENGTH_SHORT).show();
                        Log.d("SignUp","Email pattern OK");
                        flag = true;
                    } else {
                        Toast.makeText(Signup.this, "Email 형식을 확인해주세요.", Toast.LENGTH_SHORT).show();
                        Log.d("SignUp","Email pattern NG");
                        flag = false;
                    }
                } else {
                    //Toast.makeText(Signup.this, "포커스아웃", Toast.LENGTH_SHORT).show();
                    Log.d("SignUp","onFocusChange-else 실행");
                }
            }
        });

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            // 회원가입 로직을 처리할 메서드
                String str = null;
                str = String.valueOf(sendMain());
                Toast.makeText(Signup.this, "str", Toast.LENGTH_SHORT).show();
                Log.d("sendMain확인",str);
                if(sendMain())  {
                    Log.d("SignupSendData","Task 실행");
                    // 기능 구현후 Task 실행
                    new SendSignupDataTaask().execute();
                }
            }
        });
    }

    public boolean sendMain(){


        String strPwd = pwd.getText().toString();
        String strRePwd = repwd.getText().toString();
        // --------------------- 각각에 동작을 분할 ---------------------
        // --------------------- 유효성 검사 ---------------------
        if(comparePwd(strPwd, strRePwd )){
            Toast.makeText(this, "비번패턴 매칭 OK", Toast.LENGTH_SHORT).show();
            // 입력한 2개의 비번을 비교
            state |= 0x02;
        }
        // 해당하는 오류 메세지 출력
        stateMessage(state);
        if(state == 0x00){
            return false;
        }else{
            return true;
        }
    }

    private void stateMessage(byte state){
        switch (state){
            case 0x01:  // Email 입력 오류
//                Toast.makeText(this, "ID 오류", Toast.LENGTH_SHORT).show();
//                Log.d("stateMessage","ID format 오류");
                break;
            case 0x02:  // 비번 매칭 OK
                Toast.makeText(this, "pwd pattern OK", Toast.LENGTH_SHORT).show();
                Log.d("stateMessage","pwd pattern OK");
                break;
            default:
                break;
        }
    }

    public boolean comparePwd(String pwd, String repwd){
        if(repwd.equals(pwd)){
            return true;
        } else {
            return false;
        }
    }

    public class SendSignupDataTaask extends AsyncTask<String, Void, String>{
        @Override
        protected String doInBackground(String... email) {
            executeSend(email);
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Log.d("SendSignup","onPostExcute" +s);
        }

        public  String executeSend(String... email){
            Log.d("Signup DATA ","email[0]"+email[0]);
            return null;
        }
    }
}
