package com.bizpoll.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.bizpoll.dto.GetCtprvnMesureSidoLIstDTO;
import com.bizpoll.mybatis.SqlMapConfig;

public class GetCtprvnMesureSidoLIstDAO {
	private static GetCtprvnMesureSidoLIstDAO instance = new GetCtprvnMesureSidoLIstDAO();
	
	public static GetCtprvnMesureSidoLIstDAO getInstance() {
		return instance;
	}

	// MyBatis 셋팅값 불러오기
	SqlSessionFactory sqlSessionFactory = SqlMapConfig.getSqlSession();
	
	// mapper에 접근하기 위한 SqlSession
	SqlSession sqlSession;
	
	// fineDustNum 최대값 취득(시퀀스처럼 활용하기 위함)
	public int fineDustMaxNum() {
		sqlSession = sqlSessionFactory.openSession();
		
		int result = 0;
		
		try {
			result = sqlSession.selectOne("fineDustMaxNum");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		
		return result;
	}
	
	// FineDust 데이터 등록
	public int createFineDust(List<GetCtprvnMesureSidoLIstDTO> fineDustList) {
		// session 열기 (false를 이용하는 이유는 auto commit기능을 사용하기 위함)
		sqlSession = sqlSessionFactory.openSession();

		int result = 0;
		
		try {
			result = sqlSession.insert("createFineDust", fineDustList);
			sqlSession.commit(); // insert, update, delete시 반드시 commit을 해줘야 함.
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
		
		return result;
	}
}
