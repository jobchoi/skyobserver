package com.bizpoll.finedust;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import com.bizpoll.dao.GetCtprvnMesureSidoLIstDAO;
import com.bizpoll.dto.GetCtprvnMesureSidoLIstDTO;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class AndroidOpenApiAirKoreaGetCtprvnMesureSidoLIst {

	public AndroidOpenApiAirKoreaGetCtprvnMesureSidoLIst() {

	}
	
	public void findDust() {
		int fineDustNum = 0;
		BufferedReader reader = null;
		try {
			String[] sidoNameArr = {"서울", "부산", "대구", "인천", "광주", "대전", "울산", "경기", "강원", "충북", "충남", "전북", "전남", "경북", "경남", "제주", "세종"};
			List<GetCtprvnMesureSidoLIstDTO> dataList = new ArrayList<>();
			
			GetCtprvnMesureSidoLIstDAO getCtprvnMesureSidoLIstDAO = new GetCtprvnMesureSidoLIstDAO();
			
			fineDustNum = getCtprvnMesureSidoLIstDAO.fineDustMaxNum();
					
//			System.out.println("fineDustNum : " + fineDustNum);
			for (int i = 0; i < sidoNameArr.length; i++) {
				
				// 미세먼지 공공데이터 주소
				String requestUrl = "http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getCtprvnMesureSidoLIst?searchCondition=DAILY&pageNo=1&numOfRows=10&_returnType=json";
				requestUrl += "&ServiceKey=YOUR Service Key";
				requestUrl += "&sidoName=" + sidoNameArr[i];
				
				URL url = new URL(requestUrl);
				URLConnection conn = url.openConnection();
				
				reader 
				= new BufferedReader(new InputStreamReader(conn.getInputStream()));
				
				StringBuilder sb = new StringBuilder();
				String line = null;
				while ((line = reader.readLine()) != null) {
					sb.append(line + "\n"); // 문자열 붙이기
				}
				
				JsonObject jsonObject = (JsonObject) new JsonParser().parse(sb.toString()).getAsJsonObject();
				JsonArray jsonArray = jsonObject.getAsJsonArray("list");
				
				for (int j = 0; j < jsonArray.size(); j++) {
					JsonObject findDustInfo = (JsonObject) jsonArray.get(j);
					String cityName = findDustInfo.get("cityName").getAsString();
					String coValue = findDustInfo.get("coValue").getAsString();
					String dataTime = findDustInfo.get("dataTime").getAsString();
					String no2Value = findDustInfo.get("no2Value").getAsString();
					String o3Value = findDustInfo.get("o3Value").getAsString();
					String pm10Value = findDustInfo.get("pm10Value").getAsString();
					String pm25Value = findDustInfo.get("pm25Value").getAsString();
					String sidoName = findDustInfo.get("sidoName").getAsString();
					String so2Value = findDustInfo.get("so2Value").getAsString();
					fineDustNum++;
					
					GetCtprvnMesureSidoLIstDTO getCtprvnMesureSidoLIstDTO 
					= new GetCtprvnMesureSidoLIstDTO(fineDustNum, cityName, coValue, dataTime, no2Value, o3Value, pm10Value, pm25Value, sidoName, so2Value);
					
					dataList.add(getCtprvnMesureSidoLIstDTO);
				}
				
				Thread.sleep(5000);
			}
			
//			System.out.println("dataList : " + dataList);
			int result = getCtprvnMesureSidoLIstDAO.createFineDust(dataList);
			
			if (result > 0) {
				System.out.println("data 등록 성공");
			} else {
				System.out.println("data 등록 실패");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}