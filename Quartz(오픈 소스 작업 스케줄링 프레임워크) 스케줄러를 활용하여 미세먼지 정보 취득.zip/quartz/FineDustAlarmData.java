package com.bizpoll.quartz;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.bizpoll.finedust.AndroidOpenApiAirKoreaGetCtprvnMesureSidoLIst;

public class FineDustAlarmData implements Job {
//	private static final Logger logger = LoggerFactory.getLogger(FineDustAlarmData.class);
	
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		// 비지니스 로직 구현
		AndroidOpenApiAirKoreaGetCtprvnMesureSidoLIst findDust = new AndroidOpenApiAirKoreaGetCtprvnMesureSidoLIst();
		findDust.findDust();
		
//		System.out.println("syso Job Executed [" + new Date(System.currentTimeMillis()) + "]");
//		logger.info("logger Job Executed [" + new Date(System.currentTimeMillis()) + "]");
	}
}