package com.bizpoll.quartz;

import java.io.File;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.log4j.PropertyConfigurator;
import org.quartz.Scheduler;
import org.quartz.impl.StdSchedulerFactory;

@WebListener
public class ContextListener implements ServletContextListener {
/*
	Quatz 를 이용하여 스케줄러를 사용 할 때 Tomcat을 stop 시키면
	해당 스케줄러가 자동으로 Destory 되지 않기 때문에 다시 Tomcat 을 start 시키면
	scheduler가 중복되서 실행 되는 문제 해결을 위해contextDestroyed()를 재정의
*/
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		try {
			if (event != null && event.getServletContext() != null) {
				Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
				scheduler.shutdown(true);
				Thread.sleep(1000);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initialize log4j when the application is being started
	 */
	@Override
	public void contextInitialized(ServletContextEvent event) {
		// initialize log4j here
		ServletContext context = event.getServletContext();
		String log4jConfigFile = context.getInitParameter("log4jConfigLocation");
		String fullPath = context.getRealPath("") + File.separator + log4jConfigFile;

		PropertyConfigurator.configure(fullPath);
	}
}
