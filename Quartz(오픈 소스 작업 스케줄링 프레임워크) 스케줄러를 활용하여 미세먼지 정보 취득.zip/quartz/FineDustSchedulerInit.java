package com.bizpoll.quartz;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import javax.servlet.http.HttpServlet;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

public class FineDustSchedulerInit extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	private SchedulerFactory schedulerFactory;
	private Scheduler scheduler;
	
	public FineDustSchedulerInit() {
		try {
			schedulerFactory = new StdSchedulerFactory();
			scheduler = schedulerFactory.getScheduler();
			
			scheduler.start();
			
			//"job이름, 그룹명, 동작시킬Class" 
			JobDetail job = newJob(FineDustAlarmData.class)
							.withIdentity("jobFineDustAlarmData", scheduler.DEFAULT_GROUP)
							.build();
			
			// 매 2시간 간격으로 실행
			Trigger trigger = newTrigger()
							  .withIdentity("triggerFineDustAlarmData", scheduler.DEFAULT_GROUP)
							  .withSchedule(cronSchedule("0 0 0/2 * * ?"))
							  .build();
			
//			테스트용
//			.withSchedule(cronSchedule("0 0/10 * * * ?")) 매 10분 간격으로 실행
//			.withSchedule(cronSchedule("0 0 0/2 * * ?")) 매 2시간 간격으로 실행
			scheduler.scheduleJob(job, trigger);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		new FineDustSchedulerInit();
	}
}