package com.bizpoll.dto;
// (6) 시군구별 실시간 평균정보 조회 오퍼레이션
public class GetCtprvnMesureSidoLIstDTO {

	private int fineDustNum;	// pk용
    private String cityName;	// 시군구
    private String coValue;		// 일산화탄소 평균농도 (단위 : ppm)
    private String dataTime;	// 측정일시
    private String no2Value;	// 이산화질소 평균농도 (단위 : ppm)
    private String o3Value;		// 오존 평균농도 (단위 : ppm)
    private String pm10Value;	// 미세먼지(PM10) 평균농도 (단위:㎍/㎥)
    private String pm25Value;	// 미세먼지(PM2.5) 평균농도 (단위:㎍/㎥)
    private String sidoName;	// 시도 명
    private String so2Value;	// 아황산가스 평균농도 (단위 : ppm)

    public GetCtprvnMesureSidoLIstDTO() {
	}

	public GetCtprvnMesureSidoLIstDTO(int fineDustNum, String cityName, String coValue, String dataTime,
			String no2Value, String o3Value, String pm10Value, String pm25Value, String sidoName, String so2Value) {
		super();
		this.fineDustNum = fineDustNum;
		this.cityName = cityName;
		this.coValue = coValue;
		this.dataTime = dataTime;
		this.no2Value = no2Value;
		this.o3Value = o3Value;
		this.pm10Value = pm10Value;
		this.pm25Value = pm25Value;
		this.sidoName = sidoName;
		this.so2Value = so2Value;
	}

	public int getFineDustNum() {
		return fineDustNum;
	}

	public void setFineDustNum(int fineDustNum) {
		this.fineDustNum = fineDustNum;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getCoValue() {
		return coValue;
	}

	public void setCoValue(String coValue) {
		this.coValue = coValue;
	}

	public String getDataTime() {
		return dataTime;
	}

	public void setDataTime(String dataTime) {
		this.dataTime = dataTime;
	}

	public String getNo2Value() {
		return no2Value;
	}

	public void setNo2Value(String no2Value) {
		this.no2Value = no2Value;
	}

	public String getO3Value() {
		return o3Value;
	}

	public void setO3Value(String o3Value) {
		this.o3Value = o3Value;
	}

	public String getPm10Value() {
		return pm10Value;
	}

	public void setPm10Value(String pm10Value) {
		this.pm10Value = pm10Value;
	}

	public String getPm25Value() {
		return pm25Value;
	}

	public void setPm25Value(String pm25Value) {
		this.pm25Value = pm25Value;
	}

	public String getSidoName() {
		return sidoName;
	}

	public void setSidoName(String sidoName) {
		this.sidoName = sidoName;
	}

	public String getSo2Value() {
		return so2Value;
	}

	public void setSo2Value(String so2Value) {
		this.so2Value = so2Value;
	}

	@Override
	public String toString() {
		return "GetCtprvnMesureSidoLIstDTO [fineDustNum=" + fineDustNum + ", cityName=" + cityName + ", coValue="
				+ coValue + ", dataTime=" + dataTime + ", no2Value=" + no2Value + ", o3Value=" + o3Value
				+ ", pm10Value=" + pm10Value + ", pm25Value=" + pm25Value + ", sidoName=" + sidoName + ", so2Value="
				+ so2Value + "]";
	}
}